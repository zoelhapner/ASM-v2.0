import { convertIconsToImages } from '../../.build/helpers.mjs'

await convertIconsToImages('./icons', 'eps')
